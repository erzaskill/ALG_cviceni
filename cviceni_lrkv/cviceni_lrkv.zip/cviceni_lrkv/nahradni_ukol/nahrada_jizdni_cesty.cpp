// Postavte jízdní cestu s id X.
// Parametr: id_Cesty

#include "json.cpp"
#include "lexatomy.cpp"
#include "mzjisti.cpp"
#include "mptvlakyo_jc.cpp"
#include <iostream>
#include <string>
using namespace std;

int main(int pocParam, char* param[]){

//proveďte implementaci

}