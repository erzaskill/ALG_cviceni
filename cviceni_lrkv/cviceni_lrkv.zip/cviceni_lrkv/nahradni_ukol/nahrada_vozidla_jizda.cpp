// Nastavte lokomotivě s adresou X rychlostní stupeň Y.
// Parametry: adresa_Lokomotivy, rychlostní_Stupeň

#include "json.cpp"
#include "lexatomy.cpp"
#include "mzjisti.cpp"
#include "mptvlakyo_loko.cpp"
#include <iostream>
using namespace std;

int main(int pocParam, char* param[]){

//proveďte implementaci

}