// Změňte směr jízdy lokomotivy s adresou X na opačný.
// Parametr: adresa_Lokomotivy

#include "json.cpp"
#include "lexatomy.cpp"
#include "mzjisti.cpp"
#include "mptvlakyo_loko.cpp"
#include <iostream>
using namespace std;

int main(int pocParam, char* param[]){

//proveďte implementaci

}