// Přehoďte výhybku s id X do opačného stavu.
// Parametr: id_Výhybky

#include "json.cpp"
#include "lexatomy.cpp"
#include "mzjisti.cpp"
#include "mptvlakyo.cpp"
#include <iostream>
using namespace std;

int main(int pocParam, char* param[]){

//proveďte implementaci

}