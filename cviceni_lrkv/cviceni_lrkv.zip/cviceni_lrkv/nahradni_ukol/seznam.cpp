// Získejte seznam prvků typu X ze serveru kolejiště.
// Parametr: typ_Prvku (blocks, loks, jc)

#include "json.cpp"
#include "lexatomy.cpp"
#include "mptvlakyo.cpp"
#include <iostream>
using namespace std;

int main(int pocParam, char* param[]){

//proveďte implementaci

}